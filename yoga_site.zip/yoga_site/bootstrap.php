<!--Declare the default home path-->
<?php
$home_dir ="http://localhost/yoga_site";
?>

<!-- Bootstrap -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="<?php echo $home_dir?>/bootstrap/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="<?php echo $home_dir?>/bootstrap/js/bootstrap.min.js"></script>   
  